#ifndef CS247_PROJECT_UTILS_H
#define CS247_PROJECT_UTILS_H

#include <string>
#include <utility>
#include <vector>

using namespace std;

vector<string> splitString(const string& str);


#endif //CS247_PROJECT_UTILS_H
