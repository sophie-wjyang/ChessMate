#include "BaseDisplay.h"

BaseDisplay::BaseDisplay(const Grid& grid) : grid{grid} {}
