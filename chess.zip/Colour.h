#ifndef CS247_PROJECT_COLOUR_H
#define CS247_PROJECT_COLOUR_H

enum Colour {
    WHITE, // 0
    BLACK // 1
};

#endif //CS247_PROJECT_COLOUR_H
