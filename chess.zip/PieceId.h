#ifndef CS247_PROJECT_PIECEID_H
#define CS247_PROJECT_PIECEID_H

#include <iostream>

enum PieceId {
    KING = 'k', QUEEN = 'q', ROOK = 'r', BISHOP = 'b', KNIGHT = 'n', PAWN = 'p'
};

#endif //CS247_PROJECT_PIECEID_H
